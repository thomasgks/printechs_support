export type PortalComment = {
	name?: string;
	comment_type: string;
	comment_by: string;
	author_name: string;
	comment_on: string | null;
	is_customer_visible: number;
	content: string;
	/** Sibling Support Ticket Comment row name (threaded reply). */
	in_reply_to?: string | null;
	attachment?: string | null;
	attachment_url?: string | null;
	internal_only?: boolean;
};

export type PortalFileRow = {
	name: string;
	file_name: string;
	file_url: string;
	file_size?: number;
	creation?: string | null;
	owner?: string;
};
